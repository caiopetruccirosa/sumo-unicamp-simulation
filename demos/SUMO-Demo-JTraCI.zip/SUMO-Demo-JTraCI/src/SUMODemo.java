
import br.unicamp.jtraci.entities.TrafficLight;
import br.unicamp.jtraci.simulation.SumoSimulation;

import java.net.InetAddress;
import java.util.List;


public class SUMODemo {

    private int port = 4044;
    private String SumoConfigFile = "sumo_maps/cross-with-loops/test.sumo.cfg";
    //String SumoConfigFile = "sumo_maps/downtownCampinas/test.sumo.cfg";
    //String SumoConfigFile = "sumo_maps/box1l/test.sumo.cfg";
    //String SumoConfigFile = "sumo_maps/variable_speed_signs/test.sumo.cfg";


    public void sleep(int miliseconds) {
        try {
            Thread.sleep(miliseconds);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public SUMODemo() {

        SumoSimulation sumoSimulation = SumoSimulation.getInstance();
        try {
            Runtime.getRuntime().exec("sumo-gui -c sumo_maps/cross-with-loops/test.sumo.cfg --remote-port "+port+" -S");
            sumoSimulation.connect(InetAddress.getByName("127.0.0.1"), port);
        } catch (Exception e) {
            e.printStackTrace();
        }

        NetworkView nv = new NetworkView(sumoSimulation);

        nv.setVisible(true);


        List<TrafficLight> trafficLightList = sumoSimulation.getAllTrafficLights();

        while (true) {

            sumoSimulation.nextStep();

            int counter = 0;

            TrafficLight tl = trafficLightList.get(0);

            tl.updateEntityState();

            if (trafficLightList.size() != 0) {
                if (counter >= 50) {

                    int nextPhase = tl.getCurrentPhase() + 1 == tl.getCompleteDefinition().size() ? 0 : tl.getCurrentPhase() + 1;

                    tl.setCurrentPhase(nextPhase);

                    System.out.println("Setting phase " + tl.getCurrentPhase() + ": " + tl.getState());

                    counter = 0;

                } else {
                    counter++;
                }
            }
            sleep(200);
        }
    }

    public static void main(String[] args) {
        SUMODemo demo = new SUMODemo();
    }

}
