#!/bin/bash

sumo-gui -n downtownCampinas.net.xml -r downtownCampinas.rou.xml --summary-output output_sumo.downtownCampinas.xml
