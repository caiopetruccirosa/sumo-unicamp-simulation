/**
 * Copyright 2016 CST-Group
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package br.unicamp.MECA_Demo;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.slf4j.LoggerFactory;

import br.unicamp.MECA_Demo.codelets.behavioral.motivational.ChangeTrafficLightPhase;
import br.unicamp.MECA_Demo.codelets.behavioral.motivational.MaintainTrafficLightPhase;
import br.unicamp.MECA_Demo.codelets.behavioral.random.RandomChangePhase;
import br.unicamp.MECA_Demo.codelets.behavioral.reactive.ReactToLanesSituation;
import br.unicamp.MECA_Demo.codelets.motivational.ChangingMotivationalCodelet;
import br.unicamp.MECA_Demo.codelets.motivational.MaintainingMotivationalCodelet;
import br.unicamp.MECA_Demo.codelets.motor.TrafficLightActuator;
import br.unicamp.MECA_Demo.codelets.perceptual.SituationPerceptualCodelet;
import br.unicamp.MECA_Demo.codelets.perceptual.SmartCarPerceptualCodelet;
import br.unicamp.MECA_Demo.codelets.sensory.CurrentPhaseSensor;
import br.unicamp.MECA_Demo.codelets.sensory.MeanSpeedSensor;
import br.unicamp.MECA_Demo.codelets.sensory.OccupancySensor;
import br.unicamp.MECA_Demo.codelets.sensory.PhaseTimeSensor;
import br.unicamp.MECA_Demo.codelets.sensory.SmartCarInfoSensor;
import br.unicamp.MECA_Demo.codelets.sensory.VehicleNumberSensor;
import br.unicamp.MECA_Demo.codelets.system2.SmartCarAttentionCodelet;
import br.unicamp.MECA_Demo.codelets.system2.TrafficSoarCodelet;
import br.unicamp.cst.core.entities.Codelet;
import br.unicamp.cst.core.exceptions.CodeletActivationBoundsException;
import br.unicamp.cst.util.ExecutionTimeWriter;
import br.unicamp.cst.util.MindViewer;
import br.unicamp.cst.util.Refresher;
import br.unicamp.jtraci.entities.ControlledLinks;
import br.unicamp.jtraci.entities.InductionLoop;
import br.unicamp.jtraci.entities.Lane;
import br.unicamp.jtraci.entities.Phase;
import br.unicamp.jtraci.entities.TrafficLight;
import br.unicamp.jtraci.simulation.SumoSimulation;
import br.unicamp.meca.mind.MecaMind;
import br.unicamp.meca.system1.codelets.MotivationalBehavioralCodelet;
import br.unicamp.meca.system1.codelets.MotivationalCodelet;
import br.unicamp.meca.system1.codelets.MotorCodelet;
import br.unicamp.meca.system1.codelets.PerceptualCodelet;
import br.unicamp.meca.system1.codelets.RandomBehavioralCodelet;
import br.unicamp.meca.system1.codelets.ReactiveBehavioralCodelet;
import br.unicamp.meca.system1.codelets.SensoryCodelet;

/**
 * @author Andre e Eduardo Froes
 */
public class Main {
    
        private long CODELET_TIMESTEP = 2;
        public static long SIMULATION_TIMESTEP = 2;
        private boolean PROFILE_STATUS = true; 
        

	public Main(String ipServidor, int port, boolean sumoGui, boolean sumoConnect, long timestep, ArrayList<String> smartCarsIDs) {
            
                CODELET_TIMESTEP = timestep;
                SIMULATION_TIMESTEP = timestep;
            
		((ch.qos.logback.classic.Logger) LoggerFactory.getLogger("org.jsoar")).setLevel(ch.qos.logback.classic.Level.OFF);

		SimulationRunnable simulationRunnable = new SimulationRunnable(ipServidor, port, sumoGui, sumoConnect);
		
		/* The list of Meca Minds (or Cognitive Managers) that will be created - one for each junction */
		List<MecaMind> mecaMinds = new ArrayList<>();
		
		/* Looping through all Traffic Lights junctions in the simulation scenario, in order to capture the elements in each one of them */
		for (TrafficLight trafficLight : simulationRunnable.getTrafficLights()) {	
			
			/* Motor codelets we are about to create for this Cognitve Manager in this junction*/
			List<MotorCodelet> motorCodelets = new ArrayList<>();			
			/* Get the possible phases the controller can choose for this junction*/
			ArrayList<Phase> phases = simulationRunnable.getPhases(trafficLight);
			/* Create the motor codelet that will implement the chosen phase by our Cognitive Manager*/
			TrafficLightActuator trafficLightActuator = new TrafficLightActuator("TrafficLightActuator" + trafficLight.getID(), trafficLight, phases);
			trafficLightActuator.setProfiling(PROFILE_STATUS);
                        trafficLightActuator.setTimeStep(CODELET_TIMESTEP);
			/* Add the motor codelet to the list to be put inside MECA mind*/
			motorCodelets.add(trafficLightActuator);
			
			/* Hold the reference to each incoming lane of this junction. 
			 * Each sensory codelet will have this reference in order to be 
			 * able to read values from this incoming lane. 
			 */
			ArrayList<Lane> incomingLanes = new ArrayList<>(); 
			
			/* Hold the reference to each induction loop positioned in the 
			 * incoming lanes of this junction. Each sensory codelet will have this
			 * reference in order to be able to read values from this induction loops. 
			 */
			ArrayList<InductionLoop> inductionLoops = new ArrayList<>();	
			
			/*
			 * Hold the incoming lanes ids to be used by the smart cars
			 * sensors
			 * 
			 */
			ArrayList<String> incomingLaneIds = new ArrayList<>();
			
			/*
			 * In order to get the reference for incoming lanes and induction loops in this 
			 * specific junction, we will loop through structures called "Links" in the TraCI
			 * protocol, which are positioned inside "Controlled Links", which are positioned
			 * inside Traffic Lights (all objects in JTraci, implementing the TraCI protocol) 
			 */
			ControlledLinks controlledLinks = trafficLight.getControlledLinks();
			br.unicamp.jtraci.entities.Link[][] links = controlledLinks.getLinks();
			for (int i = 0; i < links.length; i++) {
				for (int j = 0; j < links[i].length; j++) {

					br.unicamp.jtraci.entities.Link link = links[i][j];
					Lane incomingLane = link.getIncomingLane();
					incomingLanes.add(incomingLane);
					inductionLoops.add(simulationRunnable.getInductionLoop(incomingLane));					
					incomingLaneIds.add(incomingLane.getID());
				}
			}			
			
			/* Sensory codelets we are about to create for this Cognitve Manager in this junction*/
			List<SensoryCodelet> sensoryCodelets = new ArrayList<>();	
			/* Lists that will hold the codelets ids. This is important 
			 * for the MECA mind mounting algorithm be able to glue the 
			 * codelets according to the reference architecture
			 * */
			ArrayList<String> sensoryCodeletsIds = new ArrayList<>();
			
			/*
			 * For this junction, we are going to create six sensors - occupancy, phase time, vehicle number,
			 * mean speed, current phase and smart cars. They are all going to receive references for the incoming lanes and
			 * induction loops they read from, and also the Traffic Light (junction) they are associated with.
			 * Holding sensory codelets ids in order to be able to mount
			 * the MECA mind later
			 * 
			 */
			OccupancySensor occupancySensor = new OccupancySensor("OccupancySensor_" + trafficLight.getID(), inductionLoops, incomingLanes, trafficLight);
			occupancySensor.setProfiling(PROFILE_STATUS);
                        occupancySensor.setTimeStep(CODELET_TIMESTEP);
			sensoryCodelets.add(occupancySensor);
			sensoryCodeletsIds.add(occupancySensor.getId());

			PhaseTimeSensor phaseTimeSensor = new PhaseTimeSensor("PhaseTimeSensor_" + trafficLight.getID(), trafficLight);
			phaseTimeSensor.setProfiling(PROFILE_STATUS);
                        phaseTimeSensor.setTimeStep(CODELET_TIMESTEP);
			sensoryCodelets.add(phaseTimeSensor);	
			sensoryCodeletsIds.add(phaseTimeSensor.getId());
			

			VehicleNumberSensor vehicleNumberSensor = new VehicleNumberSensor("VehicleNumberSensor_" + trafficLight.getID(), inductionLoops, incomingLanes);
			vehicleNumberSensor.setProfiling(PROFILE_STATUS);
                        vehicleNumberSensor.setTimeStep(CODELET_TIMESTEP);
			sensoryCodelets.add(vehicleNumberSensor);
			sensoryCodeletsIds.add(vehicleNumberSensor.getId());
			

			MeanSpeedSensor meanSpeedSensor = new MeanSpeedSensor("MeanSpeedSensor_" + trafficLight.getID(), inductionLoops, incomingLanes);
			meanSpeedSensor.setProfiling(PROFILE_STATUS);
                        meanSpeedSensor.setTimeStep(CODELET_TIMESTEP);
			sensoryCodelets.add(meanSpeedSensor);
			sensoryCodeletsIds.add(meanSpeedSensor.getId());
			
			
			CurrentPhaseSensor currentPhaseSensor = new CurrentPhaseSensor("CurrentPhaseSensor_" + trafficLight.getID(), trafficLight);
			currentPhaseSensor.setProfiling(PROFILE_STATUS);
                        currentPhaseSensor.setTimeStep(CODELET_TIMESTEP);
			sensoryCodelets.add(currentPhaseSensor);
			sensoryCodeletsIds.add(currentPhaseSensor.getId());
			
			/*
			 * Create the smart car sensory codelet that will read the smart car
			 * values when it approaches the junction
			 */
			ArrayList<String> smartCarSensoryCodeletsIds = new ArrayList<>();			
			if(smartCarsIDs!=null && smartCarsIDs.size() > 0){												

				SmartCarInfoSensor smartCarInfoSensor = new SmartCarInfoSensor("SmartCarInfoSensor_" + trafficLight.getID(), smartCarsIDs ,incomingLaneIds,trafficLight);           
				smartCarInfoSensor.setProfiling(PROFILE_STATUS);
                                smartCarInfoSensor.setTimeStep(CODELET_TIMESTEP);
				smartCarSensoryCodeletsIds.add(smartCarInfoSensor.getId());
				sensoryCodelets.add(smartCarInfoSensor);

			}
			
			/* Lists that will hold the codelets ids. This is important 
			 * for the MECA mind mounting algorithm be able to glue the 
			 * codelets according to the reference architecture
			 * */
			ArrayList<String> perceptualCodeletsIds = new ArrayList<>();
			ArrayList<String> changingMotivationalCodeletIds = new ArrayList<>();
			ArrayList<String> maintainMotivationalCodeletsIds = new ArrayList<>();
			
			
			/* Perceptual codelets we are about to create for this Cognitve Manager in this junction*/
			List<PerceptualCodelet> perceptualCodelets = new ArrayList<>();
			/* Motivational codelets we are about to create for this Cognitve Manager in this junction*/
			List<MotivationalCodelet> motivationalCodelets = new ArrayList<>();
			/* Random Behavioral codelets we are about to create for this Cognitve Manager in this junction*/
			List<RandomBehavioralCodelet> randomBehavioralCodelets = new ArrayList<>();
			/* Reactive Behavioral codelets we are about to create for this Cognitve Manager in this junction*/
			List<ReactiveBehavioralCodelet> reactiveBehavioralCodelets = new ArrayList<>();
			/* Motivational Behavioral codelets we are about to create for this Cognitve Manager in this junction*/
			List<MotivationalBehavioralCodelet> motivationalBehavioralCodelets = new ArrayList<>();
			
			/*
			 * Next step is to create the motivational codelets.
			 * This codelets must receive the ids of the sensory codelets,
			 * in order to be glued to them, receiving  their inputs.
			 */
			ChangingMotivationalCodelet changingMotivationalCodelet;
			MaintainingMotivationalCodelet maintainingMotivationalCodelet;

			try {
				changingMotivationalCodelet = new ChangingMotivationalCodelet("ChangingMotivationalCodelet_" + trafficLight.getID(), 0, 0.49, 0.3, sensoryCodeletsIds, new HashMap<String, Double>());
				changingMotivationalCodelet.setProfiling(PROFILE_STATUS);
                                changingMotivationalCodelet.setTimeStep(CODELET_TIMESTEP);
				maintainingMotivationalCodelet = new MaintainingMotivationalCodelet("MaintainingMotivationalCodelet_" + trafficLight.getID(), 0, 0.5, 0.9677, sensoryCodeletsIds, new HashMap<String, Double>());
				maintainingMotivationalCodelet.setProfiling(PROFILE_STATUS);
                                maintainingMotivationalCodelet.setTimeStep(CODELET_TIMESTEP);
				
				changingMotivationalCodeletIds.add(changingMotivationalCodelet.getId());
				maintainMotivationalCodeletsIds.add(maintainingMotivationalCodelet.getId());

				motivationalCodelets.add(changingMotivationalCodelet);
				motivationalCodelets.add(maintainingMotivationalCodelet);

			} catch (CodeletActivationBoundsException e) {
				e.printStackTrace();
			}
			
			/*
			 * Then, we create the Situation Perceptual codelet. 
			 * This codelet must receive the ids of the sensory codelets,
			 * in order to be glued to them, receiving  their inputs.
			 */
			SituationPerceptualCodelet situationPerceptualCodelet = new SituationPerceptualCodelet("SituationPerceptualCodelet_" + trafficLight.getID(), sensoryCodeletsIds);
			situationPerceptualCodelet.setProfiling(PROFILE_STATUS);
                        situationPerceptualCodelet.setTimeStep(CODELET_TIMESTEP);
			perceptualCodeletsIds.add(situationPerceptualCodelet.getId());
			perceptualCodelets.add(situationPerceptualCodelet);		

			/*
			 * Create the Smart car perceptual codelet, which will process the
			 * smart cars information and create high level abstractions 
			 * that will be useful for the controller decisions.
			 */
			ArrayList<String> smartCarPerceptualCodeletsIds = new ArrayList<>();			
			SmartCarPerceptualCodelet smartCarPerceptualCodelet = new SmartCarPerceptualCodelet("SmartCarPerceptualCodelet_" + trafficLight.getID(), smartCarSensoryCodeletsIds);
			smartCarPerceptualCodelet.setProfiling(PROFILE_STATUS);
                        smartCarPerceptualCodelet.setTimeStep(CODELET_TIMESTEP);
			smartCarPerceptualCodeletsIds.add(smartCarPerceptualCodelet.getId());
			perceptualCodelets.add(smartCarPerceptualCodelet);		
			
			/*
			 * Create the Smart car attention codelet, which will take the
			 * smart cars information to System 2
			 */
			smartCarPerceptualCodeletsIds.add(situationPerceptualCodelet.getId());
			SmartCarAttentionCodelet smartAttention = new SmartCarAttentionCodelet("SmartCarAttentionCodelet_" + trafficLight.getID(), smartCarPerceptualCodeletsIds,trafficLight, phases);  
			smartAttention.setProfiling(PROFILE_STATUS);
                        smartAttention.setTimeStep(CODELET_TIMESTEP);
			
			/*
			 * Create the SOAR codelet, responsible for deliberative decisions
			 * in giving priority to smart cars
			 */
                        try {                        
                          NativeUtils.loadFileFromJar("/soar_rules/soarRules.soar");
                        } catch(Exception e) {e.printStackTrace();}  
			String soarRulesPath = "soarRules.soar";			
			TrafficSoarCodelet trafficSoar = new TrafficSoarCodelet("TrafficSoarCodelet_" + trafficLight.getID(),"br.unicamp.MECA_Demo.util.SOAR_commands","TrafficSoarCodelet - " + trafficLight.getID(), new File (soarRulesPath), false);
			trafficSoar.setProfiling(PROFILE_STATUS);
                        trafficSoar.setTimeStep(CODELET_TIMESTEP);
					
			/*
			 * One of the last steps is to create the behavioral codelets,
			 * all three random, reactive and motivational types.
			 * They receive the ids of the perceptual codelets and
			 * motor codelets, in order to be glued to them, according
			 * to the reference architecture.	
			 * These codelets must receive the id of the soar codelet as well.			
			 */
			RandomChangePhase openRandomPhase = new RandomChangePhase("RandomChangePhase-TL" + trafficLight.getID(), trafficLightActuator.getId(),trafficSoar.getId());
			openRandomPhase.setProfiling(PROFILE_STATUS);
                        openRandomPhase.setTimeStep(CODELET_TIMESTEP);
			randomBehavioralCodelets.add(openRandomPhase);

			ReactToLanesSituation reactToLanesSituation = new ReactToLanesSituation("ReactToLanesSituation-TL" + trafficLight.getID(), perceptualCodeletsIds, trafficLightActuator.getId(),trafficSoar.getId());
			reactToLanesSituation.setProfiling(PROFILE_STATUS);
                        reactToLanesSituation.setTimeStep(CODELET_TIMESTEP);
			reactiveBehavioralCodelets.add(reactToLanesSituation);

			ChangeTrafficLightPhase changeTrafficLightPhase = new ChangeTrafficLightPhase("ChangeTrafficLightPhase-TL" + trafficLight.getID(), trafficLightActuator.getId(), changingMotivationalCodeletIds,trafficSoar.getId());
			changeTrafficLightPhase.setProfiling(PROFILE_STATUS);
                        changeTrafficLightPhase.setTimeStep(CODELET_TIMESTEP);
			motivationalBehavioralCodelets.add(changeTrafficLightPhase);

			MaintainTrafficLightPhase maintainTrafficLightPhase = new MaintainTrafficLightPhase("MaintainTrafficLightPhase-TL" + trafficLight.getID(), trafficLightActuator.getId(), maintainMotivationalCodeletsIds,trafficSoar.getId());
			maintainTrafficLightPhase.setProfiling(PROFILE_STATUS);
                        maintainTrafficLightPhase.setTimeStep(CODELET_TIMESTEP);
			motivationalBehavioralCodelets.add(maintainTrafficLightPhase);					                                 
			
			/*
			 * Then, we create the MecaMind for this Cognitive Manage in this junction.
			 */
			
			MecaMind mecaMind = new MecaMind("Mind of the TL "+trafficLight.getID());
			
			
			/*
			 * Inserting the System 1 codelets inside MECA mind
			 */
			mecaMind.setSensoryCodelets(sensoryCodelets);
			mecaMind.setPerceptualCodelets(perceptualCodelets);
			mecaMind.setMotivationalCodelets(motivationalCodelets);
			mecaMind.setRandomBehavioralCodelets(randomBehavioralCodelets);
			mecaMind.setReactiveBehavioralCodelets(reactiveBehavioralCodelets);
			mecaMind.setMotivationalBehavioralCodelets(motivationalBehavioralCodelets);
			mecaMind.setMotorCodelets(motorCodelets);
			
			/*
			 * Put the System 2 codelets in MECA mind before mouting
			 */
			mecaMind.setAttentionCodeletSystem1(smartAttention);
			mecaMind.setSoarCodelet(trafficSoar);
			
			/*
			 * After passing references to the codelets, we call the method 'MecaMind.mountMecaMind()', which
			 * is responsible for wiring the MecaMind altogether according to the reference architecture, including
			 * the creation of memory objects and containers which glue them together. This method is of pivotal
			 * importance and inside it resides all the value from the reference architecture created - the idea is 
			 * that the user only has to create the codelets, put them inside lists of differente types and call
			 * this method, which transparently glue the codelets together accordingly to the MECA reference 
			 * architecture.
			 */			
			mecaMind.mountMecaMind();

			/*
			 * Adding this Cognitive Manager, which lives in this specific junction, to the list of Cognitive Managers
			 * of our controller.
			 */
			mecaMinds.add(mecaMind);
			
		}
		
		/*
		 * Starting the engine of each Cognitive Manager
		 */
		for (MecaMind mecaMind : mecaMinds) {

			mecaMind.start();
			
		}

		/*
		 * Starting the simulation thread
		 */
		Thread simulationThread = new Thread(simulationRunnable);
		simulationThread.start();
		
		/*
		 * Starting the CST visualization tool in order to observe and debug the contents 
		 * of the Cognitive Manager mind.
		 */
		if(sumoGui){

			for (MecaMind mecaMind : mecaMinds) {

				List<Codelet> listOfCodelets = new ArrayList<>();
				/*
				 * Instead of inserting the sensory codelets in the
				 * CST visualization tool, let's insert the behaviroal
				 * codelets, which activation has a pivotal role.
				 */
				listOfCodelets.addAll(mecaMind.getRandomBehavioralCodelets());
				listOfCodelets.addAll(mecaMind.getReactiveBehavioralCodelets());
				listOfCodelets.addAll(mecaMind.getMotivationalBehavioralCodelets());	
				
				/*
				 * Add the SOAR codelet to the CST visualization
				 * tool
				 */
				listOfCodelets.add(mecaMind.getSoarCodelet());

				MindViewer mv = new MindViewer(mecaMind, "MECA Mind Inspection - "+mecaMind.getId(), listOfCodelets);
				mv.setRefresher(new SumoRefresher());
                                mv.setVisible(true);
			}			
		}

	}
        
        class SumoRefresher extends Refresher {
            public long refresh() {
                return(SumoSimulation.getInstance().getCurrentTime("1"));
            }
        }

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	if (args.length < 5) {
           System.out.println("Usage: AppSumoECA <P1> <P2> <P3> <P4> <P5>* <P6>* ... <Pn>*");
	   System.out.println("<P1> = SUMO Server IP");
	   System.out.println("<P2> = SUMO Server port");
	   System.out.println("<P3> = Start SUMO (-R)/ SUMO already running (-L)");
	   System.out.println("<P4> = SUMO Gui / Meca Viewer (-S) / None (-N)");
           System.out.println("<P5> = timestep for simulation and codelets (in miliseconds)");
	   System.out.println("<P6>* <P7>* ... <Pn>* = List of Smart Cars IDs (optional)"); 
           return;
        }

	String ipServidor = args[0];
	int port = Integer.valueOf(args[1]);
        if (port == 0) {
            Random ran = new Random();
            port = 2000 + ran.nextInt(60000);
            System.out.println("Using port "+port+" for communication with SUMO ...");
        }            
	
        ArrayList<String> smartCarsIDs = null;
	boolean sumoGui = false;
	boolean sumoConnect = false;

	if(args[2].equals("-R")){
	    sumoConnect = true;
        }
        if (sumoConnect) System.out.println("Starting sumo from this program ...");
        else System.out.println("Using an already set sumo simulation ...");
                
        ExecutionTimeWriter.path = "output_profiles/";        

        if(args[3].equals("-S")){
		    sumoGui = true;
        }
        if (sumoGui == true)
            System.out.println("Starting MindViewer Debugger ...");
        
        long timestep = 300;
        
        System.out.println("Trying to set a timestep of "+args[4]);
        timestep = Long.parseLong(args[4]);
        System.out.println("Using a timestep of "+timestep+" miliseconds ...");

	if(args.length > 5){
            System.out.print("Considering the following Smartcars: ");
	    smartCarsIDs = new ArrayList<>();
  	    for(int i = 5; i < args.length; i++){
		smartCarsIDs.add(args[i]);
                System.out.print(args[i]+" ");
	    }
            System.out.println("");
	}

	Main app = new Main(ipServidor, port, sumoGui, sumoConnect, timestep, smartCarsIDs);

	}

}
