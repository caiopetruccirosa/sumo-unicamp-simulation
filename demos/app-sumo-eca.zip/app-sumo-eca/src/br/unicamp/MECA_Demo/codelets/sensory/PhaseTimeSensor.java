/**
 * 
 */
package br.unicamp.MECA_Demo.codelets.sensory;

import br.unicamp.cst.core.entities.Memory;
import br.unicamp.cst.core.exceptions.CodeletActivationBoundsException;
import br.unicamp.cst.util.TimeStamp;
import br.unicamp.jtraci.entities.TrafficLight;
import br.unicamp.jtraci.simulation.SumoSimulation;
import br.unicamp.meca.system1.codelets.SensoryCodelet;

/**
 * @author andre
 *
 */
public class PhaseTimeSensor extends SensoryCodelet {
	
	private TrafficLight trafficLight;
	
	private Memory currentPhaseTimeMO;
	
	private Integer lastCurrentPhase;
	
	private Integer timeWhenLastCurrentPhaseWasSet;
	
	private SumoSimulation sumoSimulation;
        private long time_last = 0;
        private String log = "";

	/**
	 * @param id
	 * @param trafficLight
	 */
	public PhaseTimeSensor(String id, TrafficLight trafficLight) {
		super(id);
		this.trafficLight = trafficLight;
		sumoSimulation = SumoSimulation.getInstance();
	}

	@Override
	public void accessMemoryObjects() {
		
		int index=0;

		if(currentPhaseTimeMO == null)
			currentPhaseTimeMO = this.getOutput(id, index);
		
	}

	@Override
	public void calculateActivation() {
		
		try{

			setActivation(0.0d);

		} catch (CodeletActivationBoundsException e) {

			e.printStackTrace();
		}
		
	}

	@Override
	public void proc() {
            
                long new_time = TimeStamp.getTimeSinceStart();
                log = "Input codelet at "+TimeStamp.getDelaySinceStart()+" miliseconds - "+(new_time-time_last)+" since last ";
                time_last = new_time;
		
		if(trafficLight!=null){
			
			Integer currentPhase = trafficLight.getCurrentPhase();		
			
			if(lastCurrentPhase == null || !lastCurrentPhase.equals(currentPhase)){
				
				lastCurrentPhase = currentPhase;
				//timeWhenLastCurrentPhaseWasSet = sumoSimulation.getCurrentStep();
				timeWhenLastCurrentPhaseWasSet = sumoSimulation.getCurrentTime("1");
				
			}
			
			//int now = sumoSimulation.getCurrentStep();
                        int now = sumoSimulation.getCurrentTime("1");
			
			int timeWhenCurrentPhaseWasSet = now - timeWhenLastCurrentPhaseWasSet;
                        log += "-> Read phase time "+timeWhenCurrentPhaseWasSet;
			
//			System.out.println("timeWhenCurrentPhaseWasSet - "+ timeWhenCurrentPhaseWasSet);
			
			currentPhaseTimeMO.setI(timeWhenCurrentPhaseWasSet);
			
		}else {
			
			currentPhaseTimeMO.setI(null);
			
		}
                //System.out.println(log); 
		
	}

}
