package br.unicamp.MECA_Demo.codelets.motivational;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.unicamp.MECA_Demo.codelets.perceptual.SituationPerceptualCodelet;
import br.unicamp.MECA_Demo.util.LogFile;
import br.unicamp.cst.core.entities.Memory;
import br.unicamp.cst.core.exceptions.CodeletActivationBoundsException;
import br.unicamp.cst.motivational.Drive;
import br.unicamp.cst.util.TimeStamp;
import br.unicamp.jtraci.entities.Logic;
import br.unicamp.jtraci.entities.Phase;
import br.unicamp.jtraci.simulation.SumoSimulation;
import br.unicamp.meca.system1.codelets.MotivationalCodelet;

/**
 * Created by eduardofroes.
 */
public class ChangingMotivationalCodelet extends MotivationalCodelet {
    
    private LogFile lf;

	public ChangingMotivationalCodelet(String id, double level, double priority, double urgencyThreshold, ArrayList<String> sensoryCodeletsIds, HashMap<String, Double> motivaitonalCodeletsIds) throws CodeletActivationBoundsException {
		super(id, level, priority, urgencyThreshold, sensoryCodeletsIds, motivaitonalCodeletsIds);
		lf = new LogFile("","output_ChangingMotivationalCodelet_log.txt");

	}

	@Override
	public double calculateSimpleActivation(List<Memory> sensors) {


		double activation = 0;

		ArrayList<Integer> laneVehicleNumbers = null;
		ArrayList<Double> laneMeanSpeeds = null;
		List<Double> laneOccupancies = null;
		Logic currentLogic = null;
                
		for (Memory sensoryMemory : sensors) {
                        String name = sensoryMemory.getName();
                        Object info = sensoryMemory.getI();
                        
                        if (info == null) {
                            String s = getTime() + name+": null";
                            lf.log(s);
                            
                        }

			if (name != null && name.contains("OccupancySensor") && info instanceof ArrayList) {
				laneOccupancies = (ArrayList<Double>) info;
			}

			if (name != null && name.contains("MeanSpeedSensor") && info instanceof ArrayList) {

				laneMeanSpeeds = (ArrayList<Double>) info;
			}

			if (name != null && name.contains("VehicleNumberSensor") && info instanceof ArrayList) {

				laneVehicleNumbers = (ArrayList<Integer>) info;
			}

			if (name != null && name.contains("CurrentPhaseSensor") && info instanceof Logic) {

				currentLogic = (Logic) info;
			}
		}
                
//                if (currentLogic == null) {
//                    String s="-----currentLogic is null ...";
//                    logTime();
//                    for (Memory mem : sensors) {
//                        if (mem.getName().contains("CurrentPhaseSensor")) {
//                            Object o = mem.getI();
//                            s += " name = "+mem.getName();
//                            if (o == null) s += " Memory object is null ";
//                            else {
//                                s += " type: "+o.getClass().getName();
//                            }
//                        }    
//                    }
//                    lf.log(s);
//                }

		if(currentLogic!=null && currentLogic.getPhases()!=null && currentLogic.getPhases().size() > 0 && laneOccupancies!=null && laneOccupancies.size() > 0 && laneMeanSpeeds!=null && laneMeanSpeeds.size() > 0 && laneVehicleNumbers!=null && laneVehicleNumbers.size() > 0){

			List<Phase> possiblePhases = currentLogic.getPhases();

			int bestPhaseIndex = -1;

			double bestPhaseValue = Double.NEGATIVE_INFINITY;

                        //logTime();
			for(int i=0; i < possiblePhases.size(); i++)
			{
				Phase phase = possiblePhases.get(i); 			
				double phaseValue = Double.NEGATIVE_INFINITY;

				for(int j=0; j < phase.getDefinition().length();j++)
				{
					if(phase.getDefinition().charAt(j) == 'g' || phase.getDefinition().charAt(j) == 'G'){

						Integer vehicleNumber = laneVehicleNumbers.get(j);
						Double laneMeanSpeed = laneMeanSpeeds.get(j);
						Double laneOccupancy = laneOccupancies.get(j);
                                                //log3(vehicleNumber,laneMeanSpeed,laneOccupancy);

						if(vehicleNumber > 0){

							if(phaseValue == Double.NEGATIVE_INFINITY)
								phaseValue = 0.0d;							
							
							phaseValue += laneOccupancy + (1.0d - laneMeanSpeed / SituationPerceptualCodelet.AVERAGE_MEAN_SPEED);
                                                        
						}				    					
					}
				}

				if(phaseValue>bestPhaseValue)
				{
					bestPhaseValue = phaseValue;
					bestPhaseIndex = i;
				}
                                //log2(phaseValue,i);
			}
                        
                        int currentPhase = currentLogic.getCurrentPhase();

			if(bestPhaseIndex == -1 || bestPhaseIndex == currentPhase){

				activation = 0.0d;
                                //log(bestPhaseValue,bestPhaseIndex,currentPhase,activation);

			} else {

				activation = 1.0d;
                                //log(bestPhaseValue,bestPhaseIndex,currentPhase,activation);
			}

		}
                //else log_pars(laneVehicleNumbers,laneMeanSpeeds,laneOccupancies,currentLogic);
                //log_a(activation);
			
		return activation;
	}

	@Override
	public double calculateSecundaryDriveActivation(List<Memory> sensors, List<Drive> drives) {
		return 0;
	}
        
        private void log(double bestPhaseValue, int bestPhaseIndex, int currentPhase, double activation) {
            int time = SumoSimulation.getInstance().getCurrentTime("1");			
            lf.log(""+TimeStamp.getStringTimeStamp(time,"HH:mm:ss.S")+": BestPhaseValue="+bestPhaseValue+" BestPhaseIndex="+bestPhaseIndex+" CurrentPhase="+currentPhase+" activation="+activation);
        }
        
        private void log_a(double activation) {
            int time = SumoSimulation.getInstance().getCurrentTime("1");			
            lf.log(""+TimeStamp.getStringTimeStamp(time,"HH:mm:ss.S")+" activation="+activation);
        }
        
        private String getTime() {
            int time = SumoSimulation.getInstance().getCurrentTime("1");			
            String s = TimeStamp.getStringTimeStamp(time,"HH:mm:ss.S")+":";
            return s;
        }
        
        private void logTime() {			
            lf.log(getTime());
        }
        
        private void log2(double PhaseValue, int PhaseIndex) {
            lf.log("--- Phase Index:"+PhaseIndex+" Phase Value:"+PhaseValue);
            
        }
        
        private void log3(int vehicleNumber, double laneMeanSpeed, double laneOccupancy) {
            lf.log("--- Vehicle Number:"+vehicleNumber+" Lane Mean Speed:"+laneMeanSpeed+" Lane Occupancy:"+laneOccupancy);
            
        }
        
        private void log_pars(ArrayList<Integer> laneVehicleNumbers, ArrayList<Double> laneMeanSpeeds,List<Double> laneOccupancies, Logic currentLogic) {
            logTime();
            if (currentLogic==null) lf.log(".....currentLogic = null");
            else if (currentLogic.getPhases()==null) lf.log(".....currentLogic.getPhases() = null");
            else if (currentLogic.getPhases().size() <= 0) lf.log(".....currentLogic.getPhases().size ="+currentLogic.getPhases().size());
            if (laneOccupancies == null) lf.log(".....laneOccupancies = null");
            else if (laneOccupancies.size() <= 0) lf.log(".....laneOccupancies.size = "+laneOccupancies.size());
            if (laneMeanSpeeds==null) lf.log(".....laneMeanSpeeds = null");
            else if (laneMeanSpeeds.size() <= 0) lf.log(".....lanemeanSpeeds.size() = "+laneMeanSpeeds.size());
            if (laneVehicleNumbers == null) lf.log(".....laneVehicleNumbers = null");
            else if (laneVehicleNumbers.size() <= 0) lf.log(".....laneVehicleNumbers.size() = "+laneVehicleNumbers.size());
            
            //lf.log("currentLogic: "+currentLogic+
            //       " laneOccupancies:"+laneOccupancies+
            //       " laneMeanSpeeds:"+laneMeanSpeeds+
            //       " laneVehicleNumbers:"+laneVehicleNumbers);
            //if (laneVehicleNumbers != null)
            //  lf.log(" laneVehicleNumbers.size():"+laneVehicleNumbers.size());
            //if (currentLogic != null) {
            //     lf.log(" currentLogic.getPhases():"+currentLogic.getPhases());
            //     if (currentLogic.getPhases() != null)
            //       lf.log(" currentLogic.getPhases().size:"+currentLogic.getPhases().size());
            //}
            //if (laneOccupancies != null)
            //     lf.log(" laneOccupancies.size()"+laneOccupancies.size());
            //if (laneMeanSpeeds != null)
            //     lf.log(" laneMeanSpeeds.size"+laneMeanSpeeds.size());
                   
                   
        }
}
