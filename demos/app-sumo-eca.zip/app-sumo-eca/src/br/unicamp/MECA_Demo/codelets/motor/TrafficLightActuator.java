/**
 *     Copyright 2016 CST-Group

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */
package br.unicamp.MECA_Demo.codelets.motor;

import java.util.ArrayList;

import br.unicamp.cst.core.entities.Memory;
import br.unicamp.cst.core.exceptions.CodeletActivationBoundsException;
import br.unicamp.cst.util.TimeStamp;
import br.unicamp.jtraci.entities.Phase;
import br.unicamp.jtraci.entities.TrafficLight;
import br.unicamp.jtraci.simulation.SumoSimulation;
import br.unicamp.meca.system1.codelets.MotorCodelet;

/**
 * @author andre
 *
 */
public class TrafficLightActuator extends MotorCodelet {

	private TrafficLight trafficLight;	

	private ArrayList<Phase> phases;

	private Memory shouldChangePhaseMemory;
        private long time_last = 0;
        private String log = "";
        
	public TrafficLightActuator(String id, TrafficLight trafficLight, ArrayList<Phase> phases) {

		super(id);
		this.trafficLight = trafficLight;
		this.phases = phases;
                TimeStamp.setStartTime();
                time_last = 0;

	}

	@Override
	public void accessMemoryObjects() {

		int index=0;

		if(shouldChangePhaseMemory==null)
			shouldChangePhaseMemory = this.getInput(id, index);

	}


	@Override
	public void calculateActivation() {

		try {

			setActivation(0.0d);

		} catch (CodeletActivationBoundsException e){		

			e.printStackTrace();
		}

	}

        private void log() {
            long simtime = SumoSimulation.getInstance().getCurrentTime("1");
            String motorlog = TimeStamp.getStringTimeStamp(simtime,"HH:mm:ss.SSS")+": Motor codelet "+trafficLight.getID()+" with "+TimeStamp.getStringTimeStamp(simtime-time_last,"HH:mm:ss.SSS")+" since last is being commanded to CHANGE with "+shouldChangePhaseMemory.getEvaluation();
            System.out.println(motorlog);
        }

	@Override
	public void proc() {

		int phaseIndex = -1;
                //long new_time = TimeStamp.getTimeSinceStart();
                //log = "Output codelet at "+TimeStamp.getDelaySinceStart()+" miliseconds - "+(new_time-time_last)+" since last ";
                //long simtime = SumoSimulation.getInstance().getCurrentTime("1");
                //log = "Output codelet at "+TimeStamp.getStringTimeStamp(simtime,"HH:mm:ss.S");
                
                //time_last = new_time;

		if(trafficLight!=null && phases!=null && shouldChangePhaseMemory!=null && shouldChangePhaseMemory.getI()!=null){

			try{

				Boolean shouldChangePhase = (Boolean) shouldChangePhaseMemory.getI();

				if(shouldChangePhase!=null){

					if(shouldChangePhase){
                                                 
                                                //log();

						phaseIndex = trafficLight.getCurrentPhase();

						if(phaseIndex == phases.size()-1){												
							phaseIndex = 0;
						}else{
							phaseIndex++;
						}

						String nextPhase = phases.get(phaseIndex).getDefinition();

						while( ( nextPhase.contains("y") || nextPhase.contains("Y") ) || ( !nextPhase.contains("g") && !nextPhase.contains("G") ) ) {

							if(phaseIndex == phases.size()-1){												
								phaseIndex = 0;
							}else{
								phaseIndex++;
							}

							nextPhase = phases.get(phaseIndex).getDefinition();

						}							

						long simtime = SumoSimulation.getInstance().getCurrentTime("1");
                                                        
                                                if(phaseIndex >= 0 && phases.size() > phaseIndex && (simtime - time_last) >= 4000){											

							trafficLight.setCurrentPhase(phaseIndex);	
                                                        log = "Output codelet of TrafficLight "+trafficLight.getID()+" at "+TimeStamp.getStringTimeStamp(simtime,"HH:mm:ss.SSS")+" "+TimeStamp.getStringTimeStamp(simtime-time_last,"HH:mm:ss.SSS")+" since last ";
                                                        time_last = simtime;
							log += "-> Set phase "+phaseIndex;
                                                        System.out.println(log);
						}

					}								
				}	

			}catch(Exception e){

				e.printStackTrace();
			}
		}
        //System.out.println(log); 
	}

}
