/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unicamp.MECA_Demo;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.unicamp.MECA_Demo.codelets.communication.ReceiveMessageCodelet;
import br.unicamp.MECA_Demo.codelets.perceptual.SituationPerceptualCodelet;
import br.unicamp.MECA_Demo.util.LogFile;
import br.unicamp.MECA_Demo.util.graph.Graph;
import br.unicamp.MECA_Demo.util.graph.Link;
import br.unicamp.MECA_Demo.util.graph.Node;
import br.unicamp.cst.core.entities.Memory;
import br.unicamp.cst.core.entities.Mind;
import br.unicamp.cst.util.TimeStamp;
import br.unicamp.jtraci.entities.ControlledLinks;
import br.unicamp.jtraci.entities.Edge;
import br.unicamp.jtraci.entities.InductionLoop;
import br.unicamp.jtraci.entities.Junction;
import br.unicamp.jtraci.entities.Lane;
import br.unicamp.jtraci.entities.Logic;
import br.unicamp.jtraci.entities.Phase;
import br.unicamp.jtraci.entities.TrafficLight;
import br.unicamp.jtraci.simulation.SumoSimulation;

/**
 * @author gudwin, andre e eduardo froes
 */
public class SimulationRunnable implements Runnable {

    private SumoSimulation sumoSimulation;

    private List<TrafficLight> trafficLights;

    private List<InductionLoop> inductionLoops;
    private LogFile lf[];

    public SimulationRunnable(String ipServidor, int port, boolean sumoGui, boolean sumoToConnect) {

        sumoSimulation = SumoSimulation.getInstance();
        //executeCommand("sumo-gui -c sumo/twinT.sumocfg --remote-port 8000 -S &");

        if (sumoToConnect) {
            try {
                if (sumoGui) {
                    //Runtime.getRuntime().exec("sumo-gui -n sumo/twinT/twinT.net.xml -r sumo/twinT/twinT.p0.1.1.rou.xml -a sumo/twinT/twinT.add.xml --remote-port "+port+" -S");
                    Runtime.getRuntime().exec(NativeUtils.sumoCommand()+"sumo-gui -c sumo/simpleT/simpleT.sumocfg --remote-port "+port+" -S");
                } else {
                    Runtime.getRuntime().exec(NativeUtils.sumoCommand()+"sumo -c sumo/simpleT/simpleT.sumocfg --remote-port "+port+" -S");
                }
                //
                //Runtime.getRuntime().exec("sumo-gui -c sumo/twinT.sumocfg --remote-port 8000 -S");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //sumoSimulation.runSumoGui("sumo/twinT.sumocfg", port);
        //try {Thread.sleep(20000);} catch (Exception e) {e.printStackTrace();}
        System.out.println("Trying to connect... ");
        try {
            sumoSimulation.connect(InetAddress.getByName(ipServidor), port);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Connected !");
        trafficLights = sumoSimulation.getAllTrafficLights();
        System.out.println("Simulation: " + trafficLights.size() + " traffic lights loaded !");
        inductionLoops = sumoSimulation.getAllInductionLoops();
        System.out.println("Simulation: " + inductionLoops.size() + " induction loops loaded !");
        int n_trafficlights = trafficLights.size();
        lf = new LogFile[n_trafficlights];
        lastCurrentPhase = new Integer[n_trafficlights];
        timeWhenLastCurrentPhaseWasSet = new Integer[n_trafficlights];
        for (int i=0;i<n_trafficlights;i++) 
          lf[i] = new LogFile("","output_tl_"+trafficLights.get(i).getID()+"_log.csv");
    }

    @Override
    public void run() {

        try {

            int vehiclesStillToLeave = sumoSimulation.getMinExpectedNumber("1");

            while (vehiclesStillToLeave > 0) {
            	            	
                /*
				 * Next step
				 */
                sumoSimulation.nextStep(0);
                
                vehiclesStillToLeave = sumoSimulation.getMinExpectedNumber("1");
                
                try {
                    Thread.sleep(Main.SIMULATION_TIMESTEP);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //System.out.println("Tick: "+sumoSimulation.getCurrentTime("1"));
                
                int i=0;
                for (TrafficLight t : getTrafficLights()) {
                   long time = sumoSimulation.getCurrentTime("1");
                   String s = ""+time+" "+TimeStamp.getStringTimeStamp(time,"HH:mm:ss.SSS");
                   s += this.getBestValues(t);
                   //s += " "+this.getCurrentPhase(t);
                   //s += " "+this.getMeanSpeed(t);
                   //s += " "+this.getOccupancy(t);
                   s += "\n    PhaseTime: "+this.getPhaseTime(i);
                   s += " FreeMemory: "+Runtime.getRuntime().freeMemory();
                   //s += " "+this.getVehicleNumber(t);
                   lf[i++].log(s);
                }
                
            }

            sumoSimulation.close();

        } catch (IllegalStateException e) {
            e.printStackTrace();
        } finally {
            System.exit(-1);
        }

    }

    public InductionLoop getInductionLoop(Lane l) {

        String incomingLaneID = l.getID();
        InductionLoop incomingLaneInductionLoop = null;
        if (inductionLoops != null) {
            for (InductionLoop inductionLoop : inductionLoops) {
                if (inductionLoop.getLaneID().equalsIgnoreCase(incomingLaneID)) {
                    incomingLaneInductionLoop = inductionLoop;
                    break;
                }
            }
        }
        return incomingLaneInductionLoop;
    }


    public List<Edge> getOutgoingEdgesFromJunction(String junctionID) {

        List<Edge> allEdges = sumoSimulation.getAllEdges();

        List<Edge> outgoingLanes = new ArrayList<Edge>();

        for (Edge edge : allEdges) {

            String[] edgeSplited = edge.getID().split(":");
            if (edgeSplited[0].equals(junctionID)) {
                outgoingLanes.add(edge);
            }
        }
        return outgoingLanes;
    }

    public Map<TrafficLight, Memory> getReceiveInputMessageMemories(List<TrafficLight> trafficLights, Mind mind) {

        Map<TrafficLight, Memory> inputMessageBuffer = new HashMap<>();

        for (TrafficLight trafficLight : trafficLights) {

            Memory inputMessagesMO = mind.createMemoryObject(ReceiveMessageCodelet.INPUT_MESSAGE, "-1");
            inputMessageBuffer.put(trafficLight, inputMessagesMO);
        }
        return inputMessageBuffer;
    }

    public Junction findJuction(String junctionID, List<Junction> junctions) {

        Junction junction = null;
        for (Junction it : junctions) {
            if (it.getID().equals(junctionID)) {
                junction = it;
                break;
            }
        }
        return junction;
    }

    public TrafficLight findTrafficLight(String trafficLightID, List<TrafficLight> trafficLights) {

        TrafficLight trafficLight = null;
        for (TrafficLight it : trafficLights) {
            if (it.getID().equals(trafficLightID)) {
                trafficLight = it;
                break;
            }
        }
        return trafficLight;
    }

    public Graph findNeighbors(Map<String, List<Edge>> agentsOutogingEdges, List<Junction> junctions, List<TrafficLight> trafficLights) {

        Graph newGraph = new Graph("Traffic");
        List<String> agentsToDo = new ArrayList<>();
        agentsToDo.add(junctions.get(0).getID());
        List<String> agentsDone = new ArrayList<>();
        while (agentsToDo.size() > 0) {
            String junctionID = agentsToDo.get(0);
            if (!agentsDone.contains(junctionID)) {
                List<Edge> outgoingEdges = agentsOutogingEdges.get(junctionID);
                for (Edge outgoingEdge : outgoingEdges) {
                    TrafficLight trafficLight = findTrafficLight(junctionID, trafficLights);
                    Junction junction = findJuction(junctionID, junctions);
                    Node refereceNode = new Node(junctionID, trafficLight != null ? trafficLight : junction);
                    Link newLink = new Link(outgoingEdge.getID(), outgoingEdge.getCurrentTravelTime() * outgoingEdge.getLastStepMeanSpeed());
                    String[] junctionPrevious = outgoingEdge.getID().split(":");
                    TrafficLight trafficLightNewNode = findTrafficLight(junctionPrevious[1], trafficLights);
                    Junction junctionNewNode = findJuction(junctionPrevious[1], junctions);
                    Node newNode = new Node(junctionPrevious[1], trafficLightNewNode != null ? trafficLightNewNode : junctionNewNode);
                    newGraph.addNode(newNode, newLink, refereceNode);
                    agentsToDo.add(junctionPrevious[1]);
                }
                agentsToDo.remove(0);
                agentsDone.add(junctionID);
            } else {
                agentsToDo.remove(0);
            }
        }


        return newGraph;
    }

    public ArrayList<Phase> getPhases(TrafficLight trafficLight) {

        List<Logic> logics = trafficLight.getCompleteDefinition();

        ArrayList<Phase> phases = new ArrayList<>();

        for (Logic logic : logics) {

            phases.addAll(logic.getPhases());
        }
        return phases;
    }

    /**
     * @return the trafficLights
     */
    public List<TrafficLight> getTrafficLights() {
        return trafficLights;
    }
    
    public Logic getCurrentPhase(TrafficLight trafficLight) {
        Logic currentLogic = null;
        if(trafficLight!=null){
	   String currentProgram = trafficLight.getCurrentProgram();
	   if(currentProgram!=null){
		List<Logic> completeDefinition = trafficLight.getCompleteDefinition();
		if(completeDefinition!=null){
	  	    currentLogic = completeDefinition.get(Integer.valueOf(currentProgram));
		}
	   }						
        }
        return(currentLogic);
    }
    
    private String getCurrentPhaseSensor(TrafficLight trafficLight) {
        String s = "";
        s += getCurrentPhase(trafficLight).toString();
	return(s);
    }
    
    public ArrayList<Double> getMeanSpeed(TrafficLight trafficLight) {
        ArrayList<Double> laneMeanSpeeds = new ArrayList<>();
        ArrayList<Lane> incomingLanes = getIncomingLanes(trafficLight);	
        if(incomingLanes!=null && incomingLanes.size()>0){
	   for(Lane lane : incomingLanes){
	     if(lane!=null) laneMeanSpeeds.add(lane.getLastStepMeanSpeed());
	   }
        } else {
	   System.out.println("getMeanSpeed: data not available");
		}
        return(laneMeanSpeeds);
    }
    
    private String getMeanSpeedSensor(TrafficLight trafficLight) {
        String s = "";
        ArrayList<Double> laneMeanSpeeds = getMeanSpeed(trafficLight);
	s += laneMeanSpeeds.toString();
        return(s);
    }
    
    
    public ArrayList<Lane> getIncomingLanes(TrafficLight trafficLight) {
        ArrayList<Lane> incomingLanes = new ArrayList<Lane>();
        ControlledLinks controlledLinks = trafficLight.getControlledLinks();
	br.unicamp.jtraci.entities.Link[][] links = controlledLinks.getLinks();
	for (int i = 0; i < links.length; i++) {
	     for (int j = 0; j < links[i].length; j++) {
		br.unicamp.jtraci.entities.Link link = links[i][j];
		Lane incomingLane = link.getIncomingLane();
		incomingLanes.add(incomingLane);
	     }
	}
        return(incomingLanes);
    }
    
    private ArrayList<Double> getOccupancy(TrafficLight trafficLight) {
        ArrayList<Double> lanesOccupancies = new ArrayList<>();
        ArrayList<Lane> incomingLanes = getIncomingLanes(trafficLight);
        if(incomingLanes!=null && incomingLanes.size()>0){
            for(Lane lane : incomingLanes){
                if(lane!=null)
                    lanesOccupancies.add(lane.getLastStepOccupancy());
            }
	} else {
	   System.out.println("getOccupancy: data not available");
	}
        return(lanesOccupancies);
    }
    
    private String getOccupancySensor(TrafficLight trafficLight) {
        String s = "";
        ArrayList<Double> lanesOccupancies = getOccupancy(trafficLight);
        s += lanesOccupancies.toString();
	return(s);
    }
    
    private Integer lastCurrentPhase[];
    private Integer timeWhenLastCurrentPhaseWasSet[];
    
//    public long getPhaseTime(TrafficLight trafficLight) {
//        long time = 0;
//        if(trafficLight!=null){
//	    Integer currentPhase = trafficLight.getCurrentPhase();		
//	    if(lastCurrentPhase == null || !lastCurrentPhase.equals(currentPhase)){
//		lastCurrentPhase = currentPhase;
//		//timeWhenLastCurrentPhaseWasSet = sumoSimulation.getCurrentStep();
//		timeWhenLastCurrentPhaseWasSet = sumoSimulation.getCurrentTime("1");
//	    }
//            int now = sumoSimulation.getCurrentTime("1");
//	    int timeWhenCurrentPhaseWasSet = now - timeWhenLastCurrentPhaseWasSet;
//            time = timeWhenCurrentPhaseWasSet;
//	} else {
//	   System.out.println("getPhaseTime: data not available");	
//	}
//        return(time);
//    }
    
    public long getPhaseTime(int tl_n) {
        TrafficLight trafficLight = trafficLights.get(tl_n);
        long time = 0;
        if(trafficLight!=null){
	    Integer currentPhase = trafficLight.getCurrentPhase();		
	    if(lastCurrentPhase[tl_n] == null || !lastCurrentPhase[tl_n].equals(currentPhase)){
		lastCurrentPhase[tl_n] = currentPhase;
		//timeWhenLastCurrentPhaseWasSet = sumoSimulation.getCurrentStep();
		timeWhenLastCurrentPhaseWasSet[tl_n] = sumoSimulation.getCurrentTime("1");
	    }
            int now = sumoSimulation.getCurrentTime("1");
	    int timeWhenCurrentPhaseWasSet = now - timeWhenLastCurrentPhaseWasSet[tl_n];
            time = timeWhenCurrentPhaseWasSet;
	} else {
	   System.out.println("getPhaseTime: data not available");	
	}
        return(time);
    }
    
//    private String getPhaseTimeSensor(TrafficLight trafficLight) {
//        String s = "";
//        s += getPhaseTime(trafficLight);
//        return(s);
//    }
    
    private String getVehicleNumberSensor(TrafficLight trafficLight) {
        String s = "";
        ArrayList<Lane> incomingLanes = getIncomingLanes(trafficLight);
        if(incomingLanes!=null && incomingLanes.size()>0){
   	   ArrayList<Integer> laneVehicleNumbers = new ArrayList<>();
 	   for(Lane lane : incomingLanes){
		if(lane!=null)
		   laneVehicleNumbers.add(lane.getLastStepVehicleNumber());
	   }
	   s += laneVehicleNumbers.toString();
	} else {
	   System.out.println("getVehicleNumber(): data not available");
	}
        return(s);
    }
    
    public ArrayList<Integer> getVehicleNumber(TrafficLight trafficLight) {
        ArrayList<Integer> laneVehicleNumbers = new ArrayList<>();
        ArrayList<Lane> incomingLanes = getIncomingLanes(trafficLight);
        if(incomingLanes!=null && incomingLanes.size()>0){
   	   for(Lane lane : incomingLanes){
		if(lane!=null)
		   laneVehicleNumbers.add(lane.getLastStepVehicleNumber());
	   }
	} else {
	   System.out.println("getVehicleNumber(): data not available");
	}
        return(laneVehicleNumbers);
    }
    
    private String getBestValues(TrafficLight trafficLight) {
        ArrayList<Integer> laneVehicleNumbers = getVehicleNumber(trafficLight);
        ArrayList<Double> laneMeanSpeeds = getMeanSpeed(trafficLight);
        ArrayList<Double> laneOccupancies = getOccupancy(trafficLight);
        ArrayList<Integer> phaseVehicleNumbers = new ArrayList<Integer>();
        ArrayList<Double> phaseValues = new ArrayList<Double>();
        Logic currentLogic = getCurrentPhase(trafficLight);
        List<Phase> possiblePhases = currentLogic.getPhases();
	int bestPhaseIndex = -1;
	double bestPhaseValue = Double.NEGATIVE_INFINITY;
        double currentPhaseValue = Double.NEGATIVE_INFINITY;
        int currentPhase = currentLogic.getCurrentPhase();
	for(int i=0; i < possiblePhases.size(); i++) {
            Phase phase = possiblePhases.get(i); 			
            double phaseValue = Double.NEGATIVE_INFINITY;
            int phaseVehicleNumber = 0;
            for(int j=0; j < phase.getDefinition().length();j++) {
                 if(phase.getDefinition().charAt(j) == 'g' || phase.getDefinition().charAt(j) == 'G'){
                    Integer vehicleNumber = laneVehicleNumbers.get(j);
                    phaseVehicleNumber += vehicleNumber;
                    Double laneMeanSpeed = laneMeanSpeeds.get(j);
                    Double laneOccupancy = laneOccupancies.get(j);
                    if(vehicleNumber > 0) {
                        if(phaseValue == Double.NEGATIVE_INFINITY) phaseValue = 0.0d;							
			phaseValue += laneOccupancy + (1.0d - laneMeanSpeed / SituationPerceptualCodelet.AVERAGE_MEAN_SPEED);
                    }				    					
		 }
            }
            phaseValues.add(phaseValue);
            phaseVehicleNumbers.add(phaseVehicleNumber);
	    if(phaseValue>bestPhaseValue) {
		bestPhaseValue = phaseValue;
		bestPhaseIndex = i;
            }
            if (i == currentPhase) currentPhaseValue = phaseValue;
        }
        
        //String s = "    "+trafficLight.getID()+"\n    Current: ";
        String s = " Current: ";
        s += currentPhase+" ";
        //System.out.println(phaseVehicleNumbers.size()+" "+currentPhase+" "+bestPhaseIndex);
        s += phaseVehicleNumbers.get(currentPhase)+" ";
        s += String.format("%4.2f",currentPhaseValue)+" Best: ";
        s += bestPhaseIndex+" ";
        if (bestPhaseIndex >= 0 & bestPhaseIndex < phaseVehicleNumbers.size())
           s += phaseVehicleNumbers.get(bestPhaseIndex)+" ";
        else s += "-1 ";
        s += String.format("%4.2f",bestPhaseValue)+"\n    | ";
        for (int i=0;i<phaseVehicleNumbers.size();i++)
          if (phaseVehicleNumbers.get(i) > 0)  
            s += "  "+i+"> "+phaseVehicleNumbers.get(i)+" "+String.format("%4.2f",phaseValues.get(i))+" ";
        return(s);
    }
}
