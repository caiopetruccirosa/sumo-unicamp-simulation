/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unicamp.MECA_Demo.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 *
 * @author rgudwin
 */
public class LogFile {
    
    BufferedWriter writer = null;
    
    public LogFile(String path, String filename) {
        
	try {
             File directory = new File(path);
             if (! directory.exists()){
                   directory.mkdirs();
                 // If you require it to make the entire directory path including parents,
                 // use directory.mkdirs(); here instead.
             }
             File logFile = new File(path+filename);
             
	            // This will output the full path where the file will be written to...
	            //System.out.println("Creating log with profile at ... "+logFile.getCanonicalPath());
	            
             writer = new BufferedWriter(new FileWriter(logFile, false));
	     
	} catch (Exception e) { e.printStackTrace();}
        
    }
    
    public void log(Object o) {
        try {
           writer.write(o.toString()+"\n");
           writer.flush();
           //System.out.println("Logging");
        } catch (Exception e) { e.printStackTrace();}
    }    
    
}
