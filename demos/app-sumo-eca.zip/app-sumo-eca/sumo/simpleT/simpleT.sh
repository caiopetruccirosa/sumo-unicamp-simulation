#!/bin/bash

sumo-gui -c simpleT.sumocfg
