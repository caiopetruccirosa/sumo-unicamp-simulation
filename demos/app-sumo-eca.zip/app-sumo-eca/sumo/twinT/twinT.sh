#!/bin/bash

sumo-gui -c twinT.sumocfg 
