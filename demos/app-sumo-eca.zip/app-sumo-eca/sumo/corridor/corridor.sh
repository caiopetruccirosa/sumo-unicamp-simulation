#!/bin/bash

sumo-gui -c corridor.sumocfg
