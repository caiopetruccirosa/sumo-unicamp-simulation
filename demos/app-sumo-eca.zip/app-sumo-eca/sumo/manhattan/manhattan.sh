#!/bin/bash

sumo-gui -c manhattan.sumocfg

