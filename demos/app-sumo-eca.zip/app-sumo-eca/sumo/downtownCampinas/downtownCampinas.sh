#!/bin/bash

sumo-gui -c downtownCampinas.sumocfg
