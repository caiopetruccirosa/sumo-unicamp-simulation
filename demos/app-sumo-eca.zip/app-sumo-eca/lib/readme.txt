(1) jsoar uses Google Guava specifically for its support of
maps with weak keys/values. See SymbolTableImpl.